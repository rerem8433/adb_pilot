// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#ifndef SBKVERSION_H
#define SBKVERSION_H

#define SHIBOKEN_VERSION "6.12.0"
#define SHIBOKEN_MAJOR_VERSION 6
#define SHIBOKEN_MINOR_VERSION 12
#define SHIBOKEN_MICRO_VERSION 0
#define SHIBOKEN_RELEASE_LEVEL "final"
#define SHIBOKEN_SERIAL 0
#define PYTHON_VERSION_MAJOR 3
#define PYTHON_VERSION_MINOR 12
#define PYTHON_VERSION_PATCH 9

#endif
